import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  BookOpen, 
  TrendingUp, 
  ShieldAlert, 
  Brain, 
  Send, 
  CheckCircle, 
  HelpCircle, 
  Info, 
  ChevronRight, 
  RefreshCw, 
  Play, 
  Award, 
  Layers, 
  ArrowRight, 
  Briefcase, 
  MessageSquare,
  Users,
  Lightbulb,
  DollarSign,
  Check,
  X,
  FileText
} from 'lucide-react';

// Interfaces for Chat Roleplay
interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'intro' | 'habilidades' | 'finanzas' | 'crisis' | 'ia_entrenador'>('intro');

  // --- TAB 1 STATE: CHECKBOX PROGRESS ---
  const [completedObjectives, setCompletedObjectives] = useState<Record<string, boolean>>({
    obj1: false,
    obj2: false,
    obj3: false,
    obj4: false,
    obj5: false,
    obj6: false,
  });

  const toggleObjective = (id: string) => {
    setCompletedObjectives(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const completedCount = Object.values(completedObjectives).filter(Boolean).length;
  const progressPercent = Math.round((completedCount / 6) * 100);

  // --- TAB 2 STATE: DETAILED HABILIDADES ---
  const [selectedHabilidad, setSelectedHabilidad] = useState<'liderazgo' | 'comunicacion' | 'resiliencia'>('liderazgo');

  // --- TAB 3 STATE: CALCULADORA FINANCIERA (FLUJOS INCREMENTALES) ---
  const [escenario, setEscenario] = useState<'A' | 'B'>('A');
  const [customInversion, setCustomInversion] = useState<number>(16000);
  const [customValorOportunidad, setCustomValorOportunidad] = useState<number>(10000);
  const [showQuizResults, setShowQuizResults] = useState<boolean>(false);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, string>>({});
  const [quizScore, setQuizScore] = useState<number | null>(null);

  const calculateVAN = (esc: 'A' | 'B', inv: number, oppVal: number) => {
    // Escenario A: Momento 0 = -inv - (-oppVal) = -inv + oppVal
    // Actually, according to the slide:
    // Transformador Viejo (Momento 0): -oppVal (-$10,000)
    // Transformador Nuevo (Momento 0): -inv (-$16,000)
    // Flujo Incremental Momento 0 = -inv - (-oppVal) = -inv + oppVal = -$16,000 - (-$10,000) = -$6,000
    // Escenario B: Momento 0 = -inv (-$16,000)
    
    const flow0 = esc === 'A' ? (-inv + oppVal) : -inv;
    
    // Year 1, 2, 3 incremental flow is standard:
    // Revenue diff = $8,500 - $5,500 = $3,000
    // Cost diff = $200 - $500 = -$300 (New cost is $200, old is $500, so new cost is $300 lower)
    // Incremental flow = Revenue diff - Cost diff = $3,000 - (-$300) = $3,300
    // Year 4 incremental flow:
    // New: Revenue $8,500 - Cost $200 + Sale $9,000 = $17,300
    // Old: Revenue $5,500 - Cost $500 + Sale $7,000 = $12,000
    // Incremental Year 4: $17,300 - $12,000 = $5,300
    
    const flow1_3 = 3300;
    const flow4 = 5300;
    
    // 10% Discount Rate
    const r = 0.10;
    const van = flow0 + 
                (flow1_3 / Math.pow(1 + r, 1)) + 
                (flow1_3 / Math.pow(1 + r, 2)) + 
                (flow1_3 / Math.pow(1 + r, 3)) + 
                (flow4 / Math.pow(1 + r, 4));
    
    return {
      flow0,
      flow1: flow1_3,
      flow2: flow1_3,
      flow3: flow1_3,
      flow4,
      van: parseFloat(van.toFixed(2))
    };
  };

  const currentCalculations = calculateVAN(escenario, customInversion, customValorOportunidad);

  const handleQuizSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let score = 0;
    if (quizAnswers.q1 === 'correct') score += 1;
    if (quizAnswers.q2 === 'correct') score += 1;
    if (quizAnswers.q3 === 'correct') score += 1;
    setQuizScore(score);
    setShowQuizResults(true);
  };

  // --- TAB 4 STATE: TALLER DE CRISIS (BRANCHING DECISION) ---
  const [crisisStep, setCrisisStep] = useState<number>(1); // 1: Role, 2: Scenario, 3: Decision 1, 4: Decision 2, 5: Decision 3, 6: Evaluation
  const [userRole, setUserRole] = useState<'lider' | 'desarrollador' | 'director'>('lider');
  const [crisisScores, setCrisisScores] = useState({ asertividad: 50, liderazgo: 50, negociacion: 50 });
  const [decisionsHistory, setDecisionsHistory] = useState<string[]>([]);

  const handleSelectRole = (role: 'lider' | 'desarrollador' | 'director') => {
    setUserRole(role);
    setCrisisStep(2);
  };

  const handleMakeDecision = (decisionIndex: number, scoresDelta: { asertividad: number, liderazgo: number, negociacion: number }, text: string) => {
    setCrisisScores(prev => ({
      asertividad: Math.max(0, Math.min(100, prev.asertividad + scoresDelta.asertividad)),
      liderazgo: Math.max(0, Math.min(100, prev.liderazgo + scoresDelta.liderazgo)),
      negociacion: Math.max(0, Math.min(100, prev.negociacion + scoresDelta.negociacion)),
    }));
    setDecisionsHistory(prev => [...prev, text]);
    setCrisisStep(prev => prev + 1);
  };

  const resetCrisisSimulation = () => {
    setCrisisStep(1);
    setCrisisScores({ asertividad: 50, liderazgo: 50, negociacion: 50 });
    setDecisionsHistory([]);
  };

  // --- TAB 5 STATE: ENTRENADOR IA CHAT ---
  const [chatSkill, setChatSkill] = useState<'liderazgo' | 'comunicacion' | 'resiliencia'>('liderazgo');
  const [chatRole, setChatRole] = useState<string>('Inversionista Ángel Exigente');
  const [chatInput, setChatInput] = useState<string>('');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);
  const [chatError, setChatError] = useState<string | null>(null);

  // Initialize Chat with correct welcome message based on role
  useEffect(() => {
    resetChat();
  }, [chatSkill, chatRole]);

  const resetChat = () => {
    let welcome = '';
    if (chatSkill === 'liderazgo') {
      welcome = `Hola, soy tu ${chatRole}. He revisado brevemente el bosquejo de tu proyecto de emprendimiento, pero honestamente tengo serias dudas sobre tu capacidad de ejecución y tu modelo de monetización. Convénceme de por qué debería invertir $100k en tu equipo. ¿Cuál es tu propuesta de valor real?`;
    } else if (chatSkill === 'comunicacion') {
      welcome = `Hola. Soy el ${chatRole}. Mira, entiendo que el cliente está furioso con el retraso de 5 días por el fallo del servidor, pero no es justo que me exijas trabajar horas extra el fin de semana. El problema fue del equipo de infraestructura, no de mi código. ¿Cómo piensas manejar esto?`;
    } else {
      welcome = `¡Qué desastre! La competencia acaba de lanzar una actualización gratuita con inteligencia artificial que copia todas nuestras funciones clave de negocio. El socio comercial está perdiendo la fe. ¿De verdad crees que podemos recuperarnos de esto o deberíamos liquidar la empresa antes de perder más dinero?`;
    }
    setChatMessages([{ role: 'assistant', content: welcome }]);
    setChatError(null);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isChatLoading) return;

    const userText = chatInput.trim();
    setChatInput('');
    setChatError(null);

    const updatedMessages = [...chatMessages, { role: 'user', content: userText } as ChatMessage];
    setChatMessages(updatedMessages);
    setIsChatLoading(true);

    try {
      const res = await fetch('/api/chat/roleplay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: updatedMessages,
          skillType: chatSkill,
          role: chatRole
        })
      });

      if (!res.ok) {
        throw new Error('No se pudo establecer conexión con el entrenador de IA de Ecotec.');
      }

      const data = await res.json();
      setChatMessages(prev => [...prev, { role: 'assistant', content: data.content }]);
    } catch (err: any) {
      console.error(err);
      setChatError(err.message || 'Error al comunicarse con Gemini.');
    } finally {
      setIsChatLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFDFD] flex flex-col font-sans text-[#444444]" id="app-container">
      
      {/* HEADER INSTITUCIONAL ACADÉMICO */}
      <header className="bg-gradient-to-r from-[#1E5FA6] to-[#2D6DB5] text-white shadow-lg shrink-0" id="main-header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="bg-white p-2 rounded-xl shadow-inner flex items-center justify-center shrink-0">
              <img 
                src="https://vinculacion.ecotec.edu.ec/wp-content/uploads/2026/04/ecotec-site-icon-1.webp" 
                alt="Logo Universidad Ecotec" 
                className="h-11 w-11 object-contain"
              />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="bg-amber-500 text-slate-900 text-[10px] font-black px-2.5 py-0.5 rounded-full tracking-wider uppercase">MODULO GRADO</span>
                <span className="text-xs text-blue-100 font-bold tracking-wide">Gestión Empresarial y Finanzas</span>
              </div>
              <h1 className="text-2xl md:text-3xl font-black tracking-tight mt-1 text-white">
                Portal de Formación Práctica: Habilidades Blandas e IA
              </h1>
            </div>
          </div>
          <div className="text-right text-xs md:text-sm text-blue-100 font-semibold select-none bg-[#1A4B83] px-4 py-2 rounded-xl border border-blue-400/20">
            <div>📍 Universidad Ecotec</div>
            <div className="text-[10px] text-blue-200 uppercase tracking-widest mt-0.5">Campus de Aprendizaje Activo</div>
          </div>
        </div>
      </header>

      {/* TABS DE NAVEGACIÓN PRINCIPAL */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-sm shrink-0" id="app-navbar">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex overflow-x-auto py-2.5 gap-2 scrollbar-none items-center justify-start md:justify-center">
            
            <button
              onClick={() => setActiveTab('intro')}
              className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all flex items-center gap-2 ${
                activeTab === 'intro' 
                  ? 'bg-[#EBF3FC] text-[#1E5FA6] shadow-sm border border-[#1E5FA6]/20' 
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Inicio y Objetivos</span>
            </button>

            <button
              onClick={() => setActiveTab('habilidades')}
              className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all flex items-center gap-2 ${
                activeTab === 'habilidades' 
                  ? 'bg-[#EBF3FC] text-[#1E5FA6] shadow-sm border border-[#1E5FA6]/20' 
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
              }`}
            >
              <Brain className="w-4 h-4" />
              <span>Habilidades Clave</span>
            </button>

            <button
              onClick={() => setActiveTab('finanzas')}
              className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all flex items-center gap-2 ${
                activeTab === 'finanzas' 
                  ? 'bg-[#EBF3FC] text-[#1E5FA6] shadow-sm border border-[#1E5FA6]/20' 
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>Flujos Incrementales (VAN)</span>
            </button>

            <button
              onClick={() => setActiveTab('crisis')}
              className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all flex items-center gap-2 ${
                activeTab === 'crisis' 
                  ? 'bg-[#EBF3FC] text-[#1E5FA6] shadow-sm border border-[#1E5FA6]/20' 
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
              }`}
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Taller de Crisis</span>
            </button>

            <button
              onClick={() => setActiveTab('ia_entrenador')}
              className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all flex items-center gap-2 ${
                activeTab === 'ia_entrenador' 
                  ? 'bg-[#EBF3FC] text-[#1E5FA6] shadow-sm border border-[#1E5FA6]/20' 
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" />
              <span>Entrenador IA en Vivo</span>
            </button>

          </div>
        </div>
      </nav>

      {/* CORE CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 overflow-auto" id="main-content">
        
        {/* ==================== TAB 1: INTRODUCCIÓN Y OBJETIVOS ==================== */}
        {activeTab === 'intro' && (
          <div className="space-y-8 animate-fade-in" id="panel-intro">
            
            {/* HERO BANNER SECTION */}
            <section className="bg-white rounded-3xl p-6 md:p-10 border border-slate-200 shadow-sm grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative overflow-hidden">
              <div className="absolute top-0 right-0 transform translate-x-12 -translate-y-12 w-64 h-64 bg-blue-50 rounded-full -z-10"></div>
              
              <div className="lg:col-span-8 space-y-4">
                <span className="text-[10px] bg-[#EBF3FC] text-[#1E5FA6] font-extrabold px-3 py-1 rounded-full tracking-widest uppercase">
                  BIENVENIDO AL MÓDULO DE APRENDIZAJE
                </span>
                <h2 className="text-2xl md:text-4xl font-extrabold text-[#1A1A1A] leading-tight">
                  Módulo de Formación Práctica en Gestión Empresarial basado en Habilidades Blandas
                </h2>
                <p className="text-sm md:text-base text-[#444444] leading-relaxed max-w-3xl">
                  En el dinámico entorno corporativo actual, poseer conocimientos técnicos y administrativos avanzados ya no basta. 
                  Este espacio te ofrece recursos interactivos y simuladores impulsados por Inteligencia Artificial para entrenar las competencias que garantizan el éxito de un emprendedor o líder organizacional: el liderazgo asertivo, la toma de decisiones estratégicas, la comunicación libre de barreras y la resiliencia proactiva.
                </p>
                <div className="flex flex-wrap gap-4 pt-2">
                  <button 
                    onClick={() => setActiveTab('habilidades')} 
                    className="bg-[#1E5FA6] hover:bg-[#2D6DB5] text-white text-xs font-bold px-5 py-3 rounded-xl shadow-md transition-all flex items-center gap-1.5"
                  >
                    <span>Comenzar el Entrenamiento</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                    <span>100% Interactivo y Autoevaluado</span>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-4 flex justify-center">
                <div className="relative p-2 bg-gradient-to-tr from-[#1E5FA6] to-emerald-500 rounded-2xl shadow-xl max-w-[280px]">
                  <div className="bg-slate-900 rounded-xl p-5 text-white space-y-4">
                    <div className="flex items-center justify-between">
                      <Briefcase className="w-8 h-8 text-blue-300" />
                      <span className="text-[10px] text-gray-400 font-mono">ID: ECO-HB-01</span>
                    </div>
                    <div>
                      <div className="text-xs text-gray-400 font-bold uppercase tracking-wider">Tu Progreso de Lectura</div>
                      <div className="text-2xl font-black mt-1 text-emerald-400">{progressPercent}%</div>
                    </div>
                    {/* Progress Bar */}
                    <div className="w-full bg-slate-800 rounded-full h-2">
                      <div className="bg-emerald-400 h-2 rounded-full transition-all duration-500" style={{ width: `${progressPercent}%` }}></div>
                    </div>
                    <div className="text-[10px] text-gray-400">
                      Completa los objetivos específicos marcando la lista de abajo para desbloquear tu medalla.
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* OBJETIVO GENERAL Y ESPECÍFICOS */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* OBJETIVO GENERAL */}
              <div className="lg:col-span-5 space-y-4">
                <h3 className="text-lg font-bold text-[#1A1A1A] flex items-center gap-2">
                  <span className="w-1.5 h-6 bg-[#1E5FA6] rounded-full"></span>
                  Objetivo General del Módulo
                </h3>
                <div className="p-8 rounded-2xl bg-[#EBF3FC] border-l-8 border-[#1E5FA6] shadow-sm space-y-3">
                  <div className="text-[10px] text-[#1E5FA6] font-bold tracking-widest uppercase">PROPÓSITO DOCENTE</div>
                  <p className="text-base md:text-lg text-[#444444] font-semibold leading-relaxed italic">
                    "Fortalecer las habilidades blandas necesarias para la gestión empresarial eficiente, promoviendo el desarrollo de competencias personales que contribuyan al liderazgo, la toma de decisiones, la innovación y el crecimiento sostenible de los emprendimientos."
                  </p>
                  <div className="text-xs text-slate-500">
                    — Extracto de la Guía del Emprendedor ECOTEC.
                  </div>
                </div>

                <div className="p-5 rounded-2xl border border-slate-200 bg-white space-y-3">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Info className="w-4 h-4 text-blue-500" />
                    ¿Por qué Habilidades Blandas?
                  </h4>
                  <p className="text-xs text-[#444444] leading-relaxed">
                    Las investigaciones demuestran que más del 85% de los éxitos en puestos directivos y emprendimientos nacientes se deben al dominio de competencias personales, emocionales e interpersonales, mientras que los conocimientos técnicos solo representan el 15% restante.
                  </p>
                </div>
              </div>

              {/* OBJETIVOS ESPECÍFICOS INTERACTIVOS */}
              <div className="lg:col-span-7 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-[#1A1A1A] flex items-center gap-2">
                    <span className="w-1.5 h-6 bg-[#1E5FA6] rounded-full"></span>
                    Objetivos Específicos de Formación
                  </h3>
                  <span className="text-xs font-bold text-[#1E5FA6] bg-blue-50 px-2.5 py-1 rounded-full">
                    {completedCount} de 6 Completados
                  </span>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed mb-4">
                  Interactúa con cada uno de los objetivos a medida que los repases en clase. Al marcarlos todos como completados, recibirás tu reconocimiento de avance.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {[
                    { id: 'obj1', text: 'Desarrollar capacidades de liderazgo para dirigir equipos de trabajo eficientemente.' },
                    { id: 'obj2', text: 'Fortalecer la comunicación efectiva y la asertividad en el ámbito empresarial.' },
                    { id: 'obj3', text: 'Mejorar la capacidad de adaptación ante cambios de mercado y situaciones adversas.' },
                    { id: 'obj4', text: 'Fomentar la creatividad y la innovación en la resolución de problemas corporativos.' },
                    { id: 'obj5', text: 'Impulsar la gestión eficiente del tiempo y de los recursos de la empresa.' },
                    { id: 'obj6', text: 'Promover el trabajo colaborativo y la construcción de redes sólidas de apoyo.' }
                  ].map((obj, index) => {
                    const isDone = completedObjectives[obj.id];
                    return (
                      <button
                        key={obj.id}
                        onClick={() => toggleObjective(obj.id)}
                        className={`text-left p-4 rounded-2xl border transition-all flex items-start gap-3 group relative overflow-hidden ${
                          isDone 
                            ? 'bg-emerald-50/70 border-emerald-300 shadow-sm' 
                            : 'bg-white border-slate-200 hover:border-[#1E5FA6] hover:bg-slate-50/50'
                        }`}
                      >
                        <div className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 mt-0.5 transition-all ${
                          isDone 
                            ? 'bg-emerald-600 border-emerald-600 text-white' 
                            : 'border-slate-300 group-hover:border-[#1E5FA6]'
                        }`}>
                          {isDone && <Check className="w-3.5 h-3.5" />}
                        </div>
                        <div className="space-y-1">
                          <span className={`text-[9px] font-bold uppercase tracking-wider block ${
                            isDone ? 'text-emerald-700' : 'text-slate-400'
                          }`}>
                            META DE APRENDIZAJE 0{index + 1}
                          </span>
                          <p className={`text-xs leading-normal ${
                            isDone ? 'text-slate-700 font-medium line-through' : 'text-slate-600'
                          }`}>
                            {obj.text}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* CONGRATULATORY CARD ONCE PROGRESS 100% */}
                {progressPercent === 100 && (
                  <div className="p-6 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-lg flex flex-col sm:flex-row items-center gap-6 animate-bounce">
                    <div className="bg-white/20 p-3 rounded-full">
                      <Award className="w-10 h-10 text-yellow-300" />
                    </div>
                    <div className="space-y-1 flex-1 text-center sm:text-left">
                      <h4 className="text-base font-black">¡Felicidades, Estudiante Ecotec!</h4>
                      <p className="text-xs text-emerald-100">
                        Has completado y comprendido todos los objetivos de formación instruccional de este módulo. Estás listo para proceder con las herramientas financieras y simulaciones prácticas de liderazgo.
                      </p>
                    </div>
                    <button 
                      onClick={() => setActiveTab('habilidades')} 
                      className="bg-white text-emerald-800 text-xs font-bold px-4 py-2.5 rounded-xl hover:bg-emerald-50 transition-colors whitespace-nowrap shadow"
                    >
                      Siguiente Tema
                    </button>
                  </div>
                )}
              </div>
            </div>

          </div>
        )}

        {/* ==================== TAB 2: HABILIDADES CLAVE ==================== */}
        {activeTab === 'habilidades' && (
          <div className="space-y-8 animate-fade-in" id="panel-habilidades">
            
            <div className="text-center max-w-3xl mx-auto space-y-2">
              <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                COMPETENCIAS REQUERIDAS
              </span>
              <h2 className="text-2xl md:text-3xl font-black text-[#1A1A1A]">Habilidades Blandas Fundamentales</h2>
              <p className="text-xs sm:text-sm text-[#444444] leading-relaxed">
                Según las directrices de la Universidad Ecotec, estas tres capacidades conforman la columna vertebral de la resiliencia corporativa y la asertividad directiva. Haz clic en cualquiera para explorar su actividad práctica.
              </p>
            </div>

            {/* TAB SELECTOR INSIDE PANELS */}
            <div className="grid grid-cols-3 gap-2 max-w-xl mx-auto bg-slate-100 p-1.5 rounded-2xl">
              {[
                { id: 'liderazgo', label: '1. Liderazgo' },
                { id: 'comunicacion', label: '2. Comunicación' },
                { id: 'resiliencia', label: '3. Resiliencia' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedHabilidad(tab.id as any)}
                  className={`py-2 px-3 text-xs font-bold rounded-xl tracking-wide transition-all ${
                    selectedHabilidad === tab.id 
                      ? 'bg-white text-[#1E5FA6] shadow' 
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* DYNAMIC CONTENT CONTAINER */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 md:p-10 max-w-5xl mx-auto">
              
              {selectedHabilidad === 'liderazgo' && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in">
                  <div className="lg:col-span-7 space-y-5">
                    <div className="flex items-center gap-3">
                      <div className="p-3 rounded-2xl bg-[#EBF3FC] text-[#1E5FA6]">
                        <Users className="w-6 h-6" />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-bold tracking-widest uppercase block">HABILIDAD BLANDA #1</span>
                        <h3 className="text-xl md:text-2xl font-black text-[#1A1A1A]">Liderazgo Transformacional</h3>
                      </div>
                    </div>

                    <p className="text-sm text-[#444444] leading-relaxed">
                      Un líder empresarial debe inspirar confianza, motivar a su equipo y orientar los esfuerzos hacia el logro de metas organizacionales. 
                      Un emprendedor que ejerce un liderazgo efectivo puede generar compromiso entre sus colaboradores, fomentar la innovación y mejorar la productividad. Además, el liderazgo facilita la toma de decisiones y la resolución de conflictos dentro de la organización de forma pacífica y asertiva.
                    </p>

                    <div className="p-6 rounded-2xl bg-[#EBF3FC] border-l-8 border-[#1E5FA6] space-y-2">
                      <span className="text-[10px] font-bold text-[#1E5FA6] uppercase tracking-wider block">CONSEJO ECOTEC</span>
                      <p className="text-xs text-[#444444] font-medium leading-relaxed italic">
                        "El desarrollo de la competencia de liderazgo no se logra de manera puramente teórica; requiere someter al estudiante a situaciones reales de fricción y toma de decisiones bajo presión extrema."
                      </p>
                    </div>
                  </div>

                  <div className="lg:col-span-5 bg-slate-50 rounded-2xl p-6 border border-slate-200 space-y-4">
                    <div className="bg-[#1E5FA6] text-white text-xs font-bold px-3.5 py-1.5 rounded-lg inline-block uppercase tracking-wider">
                      Actividad Práctica
                    </div>
                    <h4 className="text-sm font-bold text-[#1A1A1A]">Dinámica de Coordinación de Tareas</h4>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Realizar una dinámica grupal donde cada participante asuma alternamente el rol de líder para coordinar una tarea específica bajo restricción de recursos, para posteriormente evaluar la efectividad de sus directivas en base a los resultados obtenidos por el equipo.
                    </p>
                    <div className="border-t pt-3 flex items-center justify-between text-[11px] font-bold text-slate-500">
                      <span>⏱ Duración: 20 Mins</span>
                      <span>👥 Tipo: Grupal</span>
                    </div>
                    <button 
                      onClick={() => setActiveTab('crisis')} 
                      className="w-full bg-[#1E5FA6] hover:bg-[#2D6DB5] text-white py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-1.5"
                    >
                      <Play className="w-4 h-4" />
                      <span>Ir al Simulador de Crisis</span>
                    </button>
                  </div>
                </div>
              )}

              {selectedHabilidad === 'comunicacion' && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in">
                  <div className="lg:col-span-7 space-y-5">
                    <div className="flex items-center gap-3">
                      <div className="p-3 rounded-2xl bg-[#EBF3FC] text-[#1E5FA6]">
                        <MessageSquare className="w-6 h-6" />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-bold tracking-widest uppercase block">HABILIDAD BLANDA #2</span>
                        <h3 className="text-xl md:text-2xl font-black text-[#1A1A1A]">Comunicación Efectiva</h3>
                      </div>
                    </div>

                    <p className="text-sm text-[#444444] leading-relaxed">
                      La mala comunicación es la causa raíz de más del 60% de los problemas de productividad en los equipos de trabajo. 
                      Una comunicación clara y precisa reduce errores, fortalece la confianza y mejora el clima laboral. Además, contribuye directamente a la satisfacción del cliente y al fortalecimiento sostenido de la reputación de la marca en el mercado.
                    </p>

                    <div className="p-6 rounded-2xl bg-[#EBF3FC] border-l-8 border-[#1E5FA6] space-y-2">
                      <span className="text-[10px] font-bold text-[#1E5FA6] uppercase tracking-wider block">REGLA DE DIAGRAMACIÓN</span>
                      <p className="text-xs text-[#444444] font-medium leading-relaxed italic">
                        "En las empresas, la comunicación no consiste únicamente en transmitir información; implica asegurar que el receptor interprete el mensaje exactamente con la misma intención con la que fue emitido, eliminando barreras."
                      </p>
                    </div>
                  </div>

                  <div className="lg:col-span-5 bg-slate-50 rounded-2xl p-6 border border-slate-200 space-y-4">
                    <div className="bg-[#1E5FA6] text-white text-xs font-bold px-3.5 py-1.5 rounded-lg inline-block uppercase tracking-wider">
                      Actividad Práctica
                    </div>
                    <h4 className="text-sm font-bold text-[#1A1A1A]">Presentación de Pitch Comercial con Feedback</h4>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Desarrollar ejercicios de presentación oral de proyectos empresariales frente a un grupo de compañeros evaluadores, recibiendo retroalimentación estructurada sobre claridad semántica, lenguaje corporal, asertividad verbal y capacidad de persuasión.
                    </p>
                    <div className="border-t pt-3 flex items-center justify-between text-[11px] font-bold text-slate-500">
                      <span>⏱ Duración: 30 Mins</span>
                      <span>👥 Tipo: Individual / Coevaluación</span>
                    </div>
                    <button 
                      onClick={() => {
                        setChatSkill('comunicacion');
                        setChatRole('Desarrollador Líder frustrado');
                        setActiveTab('ia_entrenador');
                      }} 
                      className="w-full bg-[#1E5FA6] hover:bg-[#2D6DB5] text-white py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-1.5"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>Ir al Entrenador de IA</span>
                    </button>
                  </div>
                </div>
              )}

              {selectedHabilidad === 'resiliencia' && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in">
                  <div className="lg:col-span-7 space-y-5">
                    <div className="flex items-center gap-3">
                      <div className="p-3 rounded-2xl bg-[#EBF3FC] text-[#1E5FA6]">
                        <Lightbulb className="w-6 h-6" />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-bold tracking-widest uppercase block">HABILIDAD BLANDA #3</span>
                        <h3 className="text-xl md:text-2xl font-black text-[#1A1A1A]">Resiliencia Empresarial</h3>
                      </div>
                    </div>

                    <p className="text-sm text-[#444444] leading-relaxed">
                      La resiliencia es la capacidad de enfrentar dificultades extremas, adaptarse rápidamente a los cambios del ecosistema y recuperarse con mayor fortaleza ante situaciones adversas. 
                      En el competitivo mundo de los negocios, los emprendedores deben convivir de forma cotidiana con altos niveles de incertidumbre, ferocidad comercial y variaciones en los riesgos financieros.
                    </p>

                    <div className="p-6 rounded-2xl bg-[#EBF3FC] border-l-8 border-[#1E5FA6] space-y-2">
                      <span className="text-[10px] font-bold text-[#1E5FA6] uppercase tracking-wider block">FÓRMULA ECOTEC</span>
                      <p className="text-xs text-[#444444] font-medium leading-relaxed italic">
                        "La resiliencia permite mantener una actitud positiva y objetiva frente a los obstáculos, aprender constructivamente de los errores del equipo y continuar trabajando firmemente hacia los objetivos estratégicos establecidos."
                      </p>
                    </div>
                  </div>

                  <div className="lg:col-span-5 bg-slate-50 rounded-2xl p-6 border border-slate-200 space-y-4">
                    <div className="bg-[#1E5FA6] text-white text-xs font-bold px-3.5 py-1.5 rounded-lg inline-block uppercase tracking-wider">
                      Actividad Práctica
                    </div>
                    <h4 className="text-sm font-bold text-[#1A1A1A]">Análisis de Superación de Crisis</h4>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Analizar detalladamente casos reales de empresas multinacionales o locales que hayan logrado superar crisis macroeconómicas extremas o fallas operativas mayores, identificando las estrategias organizacionales y el liderazgo resiliente implementado para resurgir.
                    </p>
                    <div className="border-t pt-3 flex items-center justify-between text-[11px] font-bold text-slate-500">
                      <span>⏱ Duración: 25 Mins</span>
                      <span>👥 Tipo: Estudio de Caso</span>
                    </div>
                    <button 
                      onClick={() => {
                        setChatSkill('resiliencia');
                        setChatRole('Socio estresado ante la competencia');
                        setActiveTab('ia_entrenador');
                      }} 
                      className="w-full bg-[#1E5FA6] hover:bg-[#2D6DB5] text-white py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-1.5"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>Ir al Entrenador de IA</span>
                    </button>
                  </div>
                </div>
              )}

            </div>

            {/* BIBLIOGRAFÍA SUGERIDA BLOCK */}
            <div className="max-w-5xl mx-auto p-6 rounded-2xl bg-[#EBF3FC]/50 border border-blue-100 flex items-start gap-4">
              <BookOpen className="w-6 h-6 text-[#1E5FA6] shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="text-xs font-bold text-[#1E5FA6] uppercase tracking-wider block">Bibliografía Instruccional de Referencia</span>
                <p className="text-xs text-[#444444] italic">
                  Hernández Sampieri, R., & Mendoza, C. (2018). Metodología de la investigación: las rutas cuantitativa, cualitativa y mixta. McGraw-Hill.
                </p>
                <p className="text-xs text-[#444444] italic">
                  Universidad Ecotec. (2025). Guía del Emprendedor y Habilidades Blandas para Líderes del Futuro.
                </p>
              </div>
            </div>

          </div>
        )}

        {/* ==================== TAB 3: SIMULADOR DE FLUJOS INCREMENTALES (FINANZAS) ==================== */}
        {activeTab === 'finanzas' && (
          <div className="space-y-8 animate-fade-in" id="panel-finanzas">
            
            <div className="text-center max-w-3xl mx-auto space-y-2">
              <span className="text-[10px] bg-[#EBF3FC] text-[#1E5FA6] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                CASO DE ANÁLISIS FINANCIERO
              </span>
              <h2 className="text-2xl md:text-3xl font-black text-[#1A1A1A]">Simulación de Flujos Diferenciales (Incrementales)</h2>
              <p className="text-xs sm:text-sm text-[#444444] leading-relaxed">
                Determina la viabilidad económica de reemplazar un transformador viejo por uno nuevo moderno en un horizonte de 4 años, aplicando una tasa de descuento del 10%. Aprende por qué el costo de oportunidad cambia por completo las decisiones de inversión.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* INTERACTIVE INPUTS & EXCEL RENDERING */}
              <div className="lg:col-span-8 space-y-6">
                
                {/* SETTINGS CARD */}
                <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b pb-3">
                    <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-slate-400" />
                      Parámetros de Simulación en Tiempo Real
                    </h3>
                    
                    {/* ESCENARIO TOGGLER */}
                    <div className="flex bg-slate-100 p-1 rounded-xl">
                      <button
                        onClick={() => setEscenario('A')}
                        className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                          escenario === 'A' ? 'bg-[#1E5FA6] text-white shadow' : 'text-slate-500 hover:text-slate-800'
                        }`}
                      >
                        Escenario A (Costo Oportunidad CORRECTO)
                      </button>
                      <button
                        onClick={() => setEscenario('B')}
                        className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                          escenario === 'B' ? 'bg-red-600 text-white shadow' : 'text-slate-500 hover:text-slate-800'
                        }`}
                      >
                        Escenario B (SIN Costo Oportunidad INCORRECTO)
                      </button>
                    </div>
                  </div>

                  {/* CUSTOM VALUES SLIDERS */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <label className="text-xs font-bold text-slate-600">Inversión Transformador Nuevo</label>
                        <span className="text-xs font-bold text-[#1E5FA6]">${customInversion.toLocaleString()}</span>
                      </div>
                      <input 
                        type="range" 
                        min="12000" 
                        max="22000" 
                        step="500"
                        value={customInversion}
                        onChange={(e) => setCustomInversion(parseInt(e.target.value))}
                        className="w-full accent-[#1E5FA6]"
                      />
                      <div className="flex justify-between text-[10px] text-slate-400">
                        <span>$12,000</span>
                        <span>Defecto: $16,000</span>
                        <span>$22,000</span>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <label className="text-xs font-bold text-slate-600">Valor de Mercado Viejo (Costo de Oportunidad)</label>
                        <span className="text-xs font-bold text-[#1E5FA6]">${customValorOportunidad.toLocaleString()}</span>
                      </div>
                      <input 
                        type="range" 
                        min="5000" 
                        max="15000" 
                        step="500"
                        value={customValorOportunidad}
                        onChange={(e) => setCustomValorOportunidad(parseInt(e.target.value))}
                        className="w-full accent-[#1E5FA6]"
                      />
                      <div className="flex justify-between text-[10px] text-slate-400">
                        <span>$5,000</span>
                        <span>Defecto: $10,000</span>
                        <span>$15,000</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* EXCEL SHEET COMPLIANT STYLING */}
                <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden" id="excel-container">
                  <div className="bg-[#1E5FA6] p-4 text-white flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <FileText className="w-5 h-5" />
                      <span className="text-xs font-bold uppercase tracking-wider font-mono">MATRIZ DE FLUJOS EN EXCEL (TASA 10%)</span>
                    </div>
                    <span className="text-xs font-bold bg-[#2D6DB5] px-3 py-1 rounded-full">
                      Escenario Activo: {escenario === 'A' ? 'A (Correcto)' : 'B (Erróneo)'}
                    </span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse font-mono text-xs">
                      <thead>
                        <tr className="bg-[#2D6DB5] text-white">
                          <th className="p-3 font-semibold border-r border-blue-400">RUBROS Y DETALLES</th>
                          <th className="p-3 text-center border-r border-blue-400">AÑO 0</th>
                          <th className="p-3 text-center border-r border-blue-400">AÑO 1</th>
                          <th className="p-3 text-center border-r border-blue-400">AÑO 2</th>
                          <th className="p-3 text-center border-r border-blue-400">AÑO 3</th>
                          <th className="p-3 text-center">AÑO 4</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200 text-[#444444]">
                        
                        {/* SITUACION SIN PROYECTO */}
                        <tr className="bg-slate-50 font-bold text-slate-800">
                          <td colSpan={6} className="p-2.5 uppercase tracking-wide bg-slate-100 text-[10px]">SITUACIÓN SIN PROYECTO (Mantener Transformador Viejo)</td>
                        </tr>
                        <tr className="hover:bg-slate-50">
                          <td className="p-3 font-semibold text-slate-600 pl-6 border-r">Ingresos Anuales</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">$5,500</td>
                          <td className="p-3 text-center border-r">$5,500</td>
                          <td className="p-3 text-center border-r">$5,500</td>
                          <td className="p-3 text-center">$5,500</td>
                        </tr>
                        <tr className="hover:bg-slate-50">
                          <td className="p-3 font-semibold text-slate-600 pl-6 border-r">Costos de Operación</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">-$500</td>
                          <td className="p-3 text-center border-r">-$500</td>
                          <td className="p-3 text-center border-r">-$500</td>
                          <td className="p-3 text-center">-$500</td>
                        </tr>
                        <tr className="hover:bg-slate-50">
                          <td className="p-3 font-semibold text-slate-600 pl-6 border-r">Valor de Venta (Fin Año 4)</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center">$7,000</td>
                        </tr>
                        <tr className="hover:bg-slate-50">
                          <td className="p-3 font-semibold text-slate-600 pl-6 border-r">Inversión (Costo Oportunidad)</td>
                          <td className={`p-3 text-center border-r font-bold ${escenario === 'A' ? 'text-red-600 bg-red-50' : 'text-slate-400 bg-slate-100'}`}>
                            {escenario === 'A' ? `-$${customValorOportunidad.toLocaleString()}` : '$0'}
                          </td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center">$0</td>
                        </tr>
                        <tr className="bg-slate-100/70 font-semibold">
                          <td className="p-3 text-slate-700 pl-6 border-r">Flujo de Caja Viejo (Base)</td>
                          <td className="p-3 text-center border-r font-bold">{escenario === 'A' ? `-$${customValorOportunidad.toLocaleString()}` : '$0'}</td>
                          <td className="p-3 text-center border-r">$5,000</td>
                          <td className="p-3 text-center border-r">$5,000</td>
                          <td className="p-3 text-center border-r">$5,000</td>
                          <td className="p-3 text-center font-bold">$12,000</td>
                        </tr>

                        {/* SITUACION CON PROYECTO */}
                        <tr className="bg-slate-50 font-bold text-slate-800">
                          <td colSpan={6} className="p-2.5 uppercase tracking-wide bg-slate-100 text-[10px]">SITUACIÓN CON PROYECTO (Adquirir Transformador Nuevo)</td>
                        </tr>
                        <tr className="hover:bg-slate-50">
                          <td className="p-3 font-semibold text-slate-600 pl-6 border-r">Ingresos Anuales</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">$8,500</td>
                          <td className="p-3 text-center border-r">$8,500</td>
                          <td className="p-3 text-center border-r">$8,500</td>
                          <td className="p-3 text-center">$8,500</td>
                        </tr>
                        <tr className="hover:bg-slate-50">
                          <td className="p-3 font-semibold text-slate-600 pl-6 border-r">Costos de Operación</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">-$200</td>
                          <td className="p-3 text-center border-r">-$200</td>
                          <td className="p-3 text-center border-r">-$200</td>
                          <td className="p-3 text-center">-$200</td>
                        </tr>
                        <tr className="hover:bg-slate-50">
                          <td className="p-3 font-semibold text-slate-600 pl-6 border-r">Valor de Venta (Fin Año 4)</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center">$9,000</td>
                        </tr>
                        <tr className="hover:bg-slate-50">
                          <td className="p-3 font-semibold text-slate-600 pl-6 border-r">Inversión Compra Real</td>
                          <td className="p-3 text-center border-r font-bold text-red-600 bg-red-50">
                            -${customInversion.toLocaleString()}
                          </td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center border-r">$0</td>
                          <td className="p-3 text-center">$0</td>
                        </tr>
                        <tr className="bg-slate-100/70 font-semibold">
                          <td className="p-3 text-slate-700 pl-6 border-r">Flujo de Caja Nuevo</td>
                          <td className="p-3 text-center border-r font-bold">-${customInversion.toLocaleString()}</td>
                          <td className="p-3 text-center border-r">$8,300</td>
                          <td className="p-3 text-center border-r">$8,300</td>
                          <td className="p-3 text-center border-r">$8,300</td>
                          <td className="p-3 text-center font-bold">$17,300</td>
                        </tr>

                        {/* FLUJO INCREMENTAL DIFERENCIAL */}
                        <tr className="bg-yellow-50/75 font-bold text-slate-900 border-t-2 border-slate-300">
                          <td className="p-3 bg-yellow-100/40 text-[#1E5FA6] border-r">FLUJO INCREMENTAL (Nuevo - Viejo)</td>
                          <td className="p-3 text-center border-r bg-yellow-100/40 font-black text-red-700">
                            {currentCalculations.flow0 < 0 ? '-' : ''}${Math.abs(currentCalculations.flow0).toLocaleString()}
                          </td>
                          <td className="p-3 text-center border-r bg-yellow-100/40">${currentCalculations.flow1.toLocaleString()}</td>
                          <td className="p-3 text-center border-r bg-yellow-100/40">${currentCalculations.flow2.toLocaleString()}</td>
                          <td className="p-3 text-center border-r bg-yellow-100/40">${currentCalculations.flow3.toLocaleString()}</td>
                          <td className="p-3 text-center bg-yellow-100/40 font-black">${currentCalculations.flow4.toLocaleString()}</td>
                        </tr>

                      </tbody>
                    </table>
                  </div>

                  {/* BOTTOM RESULTS METRICS SUMMARY */}
                  <div className="bg-slate-50 p-6 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                    <div>
                      <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Resultado del Valor Actual Neto</div>
                      <div className="flex items-baseline gap-2 mt-1">
                        <span className={`text-3xl font-black ${
                          currentCalculations.van > 0 ? 'text-emerald-600' : 'text-red-600'
                        }`}>
                          ${currentCalculations.van.toLocaleString()}
                        </span>
                        <span className="text-xs font-bold text-slate-500">(Tasa Descuento 10%)</span>
                      </div>
                    </div>
                    <div className="text-right">
                      {currentCalculations.van > 0 ? (
                        <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-800 rounded-xl font-bold text-xs uppercase tracking-wider">
                          <CheckCircle className="w-4.5 h-4.5" />
                          <span>EL PROYECTO ES VIABLE</span>
                        </div>
                      ) : (
                        <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-100 text-red-800 rounded-xl font-bold text-xs uppercase tracking-wider animate-pulse">
                          <X className="w-4.5 h-4.5" />
                          <span>EL PROYECTO NO ES VIABLE</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

              </div>

              {/* RIGHT COLUMN: LESSON FEEDBACK & COMPREHENSION CHECK (SPAN 4) */}
              <div className="lg:col-span-4 space-y-6">
                
                {/* EDUCATIONAL DICTAMEN CARD */}
                <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                  <h3 className="text-sm font-bold text-[#1A1A1A] flex items-center gap-2 border-b pb-2">
                    <Info className="w-5 h-5 text-[#1E5FA6]" />
                    Conclusión Financiera Ecotec
                  </h3>
                  <p className="text-xs text-[#444444] leading-relaxed">
                    El dictamen correcto para toda evaluación de reemplazo corresponde al <strong className="text-[#1E5FA6]">Escenario A (Costo de Oportunidad Correcto)</strong>. 
                  </p>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    En la evaluación de proyectos de renovación, los recursos que ya posee la organización (el transformador viejo) tienen un costo implícito de oportunidad en el Momento 0. No incluirlos castiga de forma injusta y errónea a la alternativa de renovación, haciendo parecer un proyecto sumamente rentable como inviable (Escenario B).
                  </p>
                  <div className="bg-[#EBF3FC] p-4 rounded-xl text-xs text-[#444444] border-l-4 border-[#1E5FA6] font-semibold">
                    "Al restar el costo de oportunidad ($10,000) de la inversión del nuevo ($16,000), demostramos que la inversión neta adicional real es de solo $6,000."
                  </div>
                </div>

                {/* INTERACTIVE COMPREHENSION CHECK */}
                <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                  <div className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-500" />
                    <h3 className="text-sm font-bold text-[#1A1A1A]">Evaluación de Comprensión</h3>
                  </div>

                  {!showQuizResults ? (
                    <form onSubmit={handleQuizSubmit} className="space-y-4 text-xs">
                      <div className="space-y-2">
                        <p className="font-bold text-slate-700">1. ¿Qué representa matemáticamente el valor de venta hoy del activo viejo en el Año 0?</p>
                        <div className="space-y-1.5 pl-1">
                          <label className="flex items-start gap-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="q1" 
                              value="incorrect1" 
                              required
                              onChange={(e) => setQuizAnswers(prev => ({ ...prev, q1: e.target.value }))}
                              className="mt-0.5"
                            />
                            <span>Un ingreso extraordinario que tributa impuestos inmediatamente.</span>
                          </label>
                          <label className="flex items-start gap-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="q1" 
                              value="correct" 
                              onChange={(e) => setQuizAnswers(prev => ({ ...prev, q1: e.target.value }))}
                              className="mt-0.5"
                            />
                            <span className="font-medium text-[#1E5FA6]">El Costo de Oportunidad que la empresa deja de recibir al decidir quedarse con él.</span>
                          </label>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="font-bold text-slate-700">2. En el Escenario B, ¿por qué resulta un VAN negativo inviable?</p>
                        <div className="space-y-1.5 pl-1">
                          <label className="flex items-start gap-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="q2" 
                              value="correct" 
                              required
                              onChange={(e) => setQuizAnswers(prev => ({ ...prev, q2: e.target.value }))}
                              className="mt-0.5"
                            />
                            <span className="font-medium text-[#1E5FA6]">Porque sobreestima erróneamente la inversión inicial incremental, asumiendo que gastamos los $16k netos.</span>
                          </label>
                          <label className="flex items-start gap-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="q2" 
                              value="incorrect1" 
                              onChange={(e) => setQuizAnswers(prev => ({ ...prev, q2: e.target.value }))}
                              className="mt-0.5"
                            />
                            <span>Porque la tasa de descuento del 10% es excesivamente elevada para el sector eléctrico.</span>
                          </label>
                        </div>
                      </div>

                      <button 
                        type="submit"
                        className="w-full bg-[#1E5FA6] hover:bg-[#2D6DB5] text-white py-2 rounded-xl font-bold text-xs shadow-sm transition-all text-center"
                      >
                        Enviar Mis Respuestas
                      </button>
                    </form>
                  ) : (
                    <div className="space-y-4 text-xs animate-fade-in">
                      <div className="p-4 rounded-xl bg-slate-50 text-center space-y-1 border border-slate-200">
                        <div className="text-slate-400 font-bold uppercase tracking-wider">Tu Calificación de Comprensión</div>
                        <div className="text-3xl font-black text-[#1E5FA6]">{quizScore} / 2 Respuestas</div>
                        <p className="text-[11px] text-slate-500">
                          {quizScore === 2 
                            ? '¡Dominio Excelente! Has comprendido a fondo la naturaleza de los costos de oportunidad.' 
                            : 'Repasa el análisis del costo de oportunidad y vuelve a intentarlo.'}
                        </p>
                      </div>

                      <button 
                        onClick={() => { setShowQuizResults(false); setQuizScore(null); setQuizAnswers({}); }}
                        className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 py-2 rounded-xl font-bold text-xs transition-all text-center"
                      >
                        Intentar el Cuestionario de Nuevo
                      </button>
                    </div>
                  )}

                </div>

              </div>

            </div>

          </div>
        )}

        {/* ==================== TAB 4: TALLER DE CRISIS DE LIDERAZGO ==================== */}
        {activeTab === 'crisis' && (
          <div className="space-y-8 animate-fade-in" id="panel-crisis">
            
            <div className="text-center max-w-3xl mx-auto space-y-2">
              <span className="text-[10px] bg-red-100 text-red-800 font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                SIMULACIÓN DE INCIDENTE REAL
              </span>
              <h2 className="text-2xl md:text-3xl font-black text-[#1A1A1A]">Taller de Crisis: Liderazgo bajo Presión Extrema</h2>
              <p className="text-xs sm:text-sm text-[#444444] leading-relaxed">
                El servidor principal ha colapsado a 48 horas de un lanzamiento crítico valuado en $100,000. Los ánimos en la empresa están calientes. Selecciona tu rol, asume las decisiones más sabias y evalúa tu estilo de dirección.
              </p>
            </div>

            <div className="max-w-4xl mx-auto bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden" id="crisis-simulator">
              
              {/* TOP BRAND BAR */}
              <div className="bg-slate-900 p-4 text-white flex justify-between items-center text-xs">
                <span className="font-bold tracking-widest text-red-500 font-mono">● ALERTA DE SISTEMA: RETRASO OPERATIVO</span>
                <span className="font-semibold text-gray-400">Taller de 45 Minutos</span>
              </div>

              {/* STEP 1: SELECT YOUR ROLE */}
              {crisisStep === 1 && (
                <div className="p-6 md:p-10 space-y-6 text-center animate-fade-in">
                  <div className="space-y-2">
                    <h3 className="text-lg font-bold text-[#1A1A1A]">Paso 1: Selecciona Tu Rol de Participación</h3>
                    <p className="text-xs text-slate-500 max-w-2xl mx-auto">
                      Cada participante o equipo en clase debe elegir una de las siguientes perspectivas corporativas para afrontar la resolución de la crisis.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
                    
                    <button 
                      onClick={() => handleSelectRole('lider')}
                      className="p-6 rounded-2xl border border-slate-200 hover:border-[#1E5FA6] hover:bg-slate-50 transition-all text-center space-y-3 group"
                    >
                      <div className="w-12 h-12 rounded-full bg-blue-100 text-[#1E5FA6] flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                        <Users className="w-6 h-6" />
                      </div>
                      <h4 className="font-bold text-[#1A1A1A] text-sm">Líder / Gerente de Proyecto</h4>
                      <p className="text-[11px] text-slate-500 leading-relaxed">
                        Responsable directo de estructurar un plan de contingencia de emergencia para el cliente estratégico.
                      </p>
                    </button>

                    <button 
                      onClick={() => handleSelectRole('desarrollador')}
                      className="p-6 rounded-2xl border border-slate-200 hover:border-[#1E5FA6] hover:bg-slate-50 transition-all text-center space-y-3 group"
                    >
                      <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                        <Brain className="w-6 h-6" />
                      </div>
                      <h4 className="font-bold text-[#1A1A1A] text-sm">Desarrollador Líder Técnico</h4>
                      <p className="text-[11px] text-slate-500 leading-relaxed">
                        Siente que la responsabilidad es de infraestructura. Se resiste firmemente a trabajar horas extra sin compensación justa.
                      </p>
                    </button>

                    <button 
                      onClick={() => handleSelectRole('director')}
                      className="p-6 rounded-2xl border border-slate-200 hover:border-[#1E5FA6] hover:bg-slate-50 transition-all text-center space-y-3 group"
                    >
                      <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                        <DollarSign className="w-6 h-6" />
                      </div>
                      <h4 className="font-bold text-[#1A1A1A] text-sm">Director de Cuentas / Negocios</h4>
                      <p className="text-[11px] text-slate-500 leading-relaxed">
                        Presiona de manera constante y agresiva exigiendo respuestas inmediatas para calmarlos y conservar el contrato.
                      </p>
                    </button>

                  </div>
                </div>
              )}

              {/* STEP 2: CRISIS SCENARIO PRESENTATION */}
              {crisisStep === 2 && (
                <div className="p-6 md:p-10 space-y-6 animate-fade-in">
                  <div className="border-l-4 border-red-500 bg-red-50 p-5 rounded-r-2xl space-y-2">
                    <span className="text-[10px] text-red-600 font-extrabold tracking-wider block uppercase">ESCENARIO CRÍTICO</span>
                    <h3 className="text-base font-bold text-slate-800">Lanzamiento Inminente en Peligro Extremo (Contrato de $100,000)</h3>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      "Una prestigiosa firma de retail tiene programado lanzar su plataforma de comercio electrónico de última generación en 48 horas. Sin embargo, hace 1 hora, el servidor central de producción colapsó completamente, corrompiendo la base de datos de integración. El equipo estima que una recuperación tradicional tomará 5 días completos de trabajo. El cliente amenaza con cancelar el contrato de inmediato si no se entrega a tiempo."
                    </p>
                  </div>

                  <div className="space-y-3 text-xs">
                    <h4 className="font-bold text-slate-700">Tu Desafío como: <span className="text-[#1E5FA6] uppercase font-black">{userRole === 'lider' ? 'Líder de Proyecto' : userRole === 'desarrollador' ? 'Desarrollador Técnico' : 'Director de Cuentas'}</span></h4>
                    <p className="text-slate-500 leading-relaxed">
                      Deberás afrontar 3 decisiones críticas sucesivas. Tus decisiones ponderarán tu nivel de asertividad, liderazgo y capacidad de negociación para salvar al equipo y la relación corporativa.
                    </p>
                  </div>

                  <div className="pt-4 flex justify-end">
                    <button 
                      onClick={() => setCrisisStep(3)}
                      className="bg-[#1E5FA6] hover:bg-[#2D6DB5] text-white text-xs font-bold px-6 py-2.5 rounded-xl shadow transition-all flex items-center gap-1.5"
                    >
                      <span>Entrar al Desafío</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 3: DECISION 1 */}
              {crisisStep === 3 && (
                <div className="p-6 md:p-10 space-y-6 animate-fade-in">
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">PREGUNTA 1 DE 3</span>
                    <h3 className="text-base font-bold text-slate-800">Decisión Crítica: El primer acercamiento con el equipo molesto</h3>
                  </div>

                  <div className="space-y-3">
                    <button 
                      onClick={() => handleMakeDecision(
                        1, 
                        { asertividad: -15, liderazgo: 20, negociacion: -5 },
                        'Convocar a reunión urgente unilateral y ordenar horas extras obligatorias bajo apercibimiento administrativo.'
                      )}
                      className="w-full text-left p-4 rounded-xl border border-slate-200 hover:border-[#1E5FA6] hover:bg-slate-50 transition-all text-xs space-y-1"
                    >
                      <div className="font-bold text-slate-800">Opción A: Imposición Jerárquica Directa</div>
                      <p className="text-slate-500 leading-relaxed">"Reunir al equipo inmediatamente y decretar horas extras obligatorias para todos el fin de semana. No hay tiempo para discusiones."</p>
                    </button>

                    <button 
                      onClick={() => handleMakeDecision(
                        1, 
                        { asertividad: 25, liderazgo: 15, negociacion: 20 },
                        'Reconocer el esfuerzo previo del equipo, explicar asertivamente las consecuencias y ofrecer bonificación especial.'
                      )}
                      className="w-full text-left p-4 rounded-xl border border-slate-200 hover:border-[#1E5FA6] hover:bg-slate-50 transition-all text-xs space-y-1"
                    >
                      <div className="font-bold text-[#1E5FA6]">Opción B: Liderazgo Empático con Negociación</div>
                      <p className="text-slate-500 leading-relaxed">"Reconocer abiertamente el esfuerzo del equipo, disculparnos por la falla del servidor e incentivar el esfuerzo con compensación y días libres garantizados después del lanzamiento."</p>
                    </button>

                    <button 
                      onClick={() => handleMakeDecision(
                        1, 
                        { asertividad: 10, liderazgo: -10, negociacion: 10 },
                        'Buscar culpables técnicos de forma prioritaria en vez de centrar esfuerzos en restaurar la base de datos.'
                      )}
                      className="w-full text-left p-4 rounded-xl border border-slate-200 hover:border-[#1E5FA6] hover:bg-slate-50 transition-all text-xs space-y-1"
                    >
                      <div className="font-bold text-slate-800">Opción C: Transferencia de Culpa</div>
                      <p className="text-slate-500 leading-relaxed">"Iniciar una auditoría inmediata con el departamento de infraestructura para deslindar responsabilidades del equipo de desarrollo, calmando así al cliente."</p>
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 4: DECISION 2 */}
              {crisisStep === 4 && (
                <div className="p-6 md:p-10 space-y-6 animate-fade-in">
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">PREGUNTA 2 DE 3</span>
                    <h3 className="text-base font-bold text-slate-800">Decisión Crítica: Negociar la postergación o contención con el cliente enfadado</h3>
                  </div>

                  <div className="space-y-3">
                    <button 
                      onClick={() => handleMakeDecision(
                        2, 
                        { asertividad: -20, liderazgo: -10, negociacion: 15 },
                        'Ocultar la falla y mentirle al cliente diciendo que la plataforma está lista para ganar tiempo adicional.'
                      )}
                      className="w-full text-left p-4 rounded-xl border border-slate-200 hover:border-[#1E5FA6] hover:bg-slate-50 transition-all text-xs space-y-1"
                    >
                      <div className="font-bold text-slate-800">Opción A: Evasión Temporal (Mentir)</div>
                      <p className="text-slate-500 leading-relaxed">"Notificar al cliente que todo marcha según lo planeado, con el fin de ganar 24 horas valiosas antes de tener que reportar el error."</p>
                    </button>

                    <button 
                      onClick={() => handleMakeDecision(
                        2, 
                        { asertividad: 20, liderazgo: 20, negociacion: 25 },
                        'Presentar el estado real de forma transparente y plantear un lanzamiento por fases con funcionalidades críticas.'
                      )}
                      className="w-full text-left p-4 rounded-xl border border-slate-200 hover:border-[#1E5FA6] hover:bg-slate-50 transition-all text-xs space-y-1"
                    >
                      <div className="font-bold text-[#1E5FA6]">Opción B: Transparencia Radical con Solución por Fases</div>
                      <p className="text-slate-500 leading-relaxed">"Ser 100% honestos con el cliente, presentar el problema de infraestructura pero ofreciendo un plan de contingencia por etapas: habilitar catálogo de inmediato y pasarela de pago el lunes."</p>
                    </button>

                    <button 
                      onClick={() => handleMakeDecision(
                        2, 
                        { asertividad: 10, liderazgo: -10, negociacion: -15 },
                        'Aceptar de forma pasiva la cancelación de contrato y transferir el costo del siniestro al seguro corporativo.'
                      )}
                      className="w-full text-left p-4 rounded-xl border border-slate-200 hover:border-[#1E5FA6] hover:bg-slate-50 transition-all text-xs space-y-1"
                    >
                      <div className="font-bold text-slate-800">Opción C: Aceptación Pasiva y Derrota</div>
                      <p className="text-slate-500 leading-relaxed">"Explicarle al cliente que debido a un caso fortuito de fuerza mayor no llegaremos, disculparnos cortésmente y resignarnos a perder la cuenta."</p>
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 5: DECISION 3 */}
              {crisisStep === 5 && (
                <div className="p-6 md:p-10 space-y-6 animate-fade-in">
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">PREGUNTA 3 DE 3</span>
                    <h3 className="text-base font-bold text-slate-800">Decisión Crítica: Restablecer la paz interna y celebrar el aprendizaje</h3>
                  </div>

                  <div className="space-y-3">
                    <button 
                      onClick={() => handleMakeDecision(
                        3, 
                        { asertividad: 20, liderazgo: 25, negociacion: 10 },
                        'Establecer una sesión de post-mortem para documentar errores e implementar redundancia de servidores.'
                      )}
                      className="w-full text-left p-4 rounded-xl border border-slate-200 hover:border-[#1E5FA6] hover:bg-slate-50 transition-all text-xs space-y-1"
                    >
                      <div className="font-bold text-[#1E5FA6]">Opción A: Sesión Post-Mortem y Redundancia</div>
                      <p className="text-slate-500 leading-relaxed">"Una vez pasada la tormenta, reunir al equipo no para buscar culpables, sino para mapear qué falló en el despliegue técnico e implementar respaldos automáticos cada hora."</p>
                    </button>

                    <button 
                      onClick={() => handleMakeDecision(
                        3, 
                        { asertividad: -10, liderazgo: -15, negociacion: -10 },
                        'Ignorar el cansancio del equipo de trabajo y reasignarlos de inmediato a nuevos proyectos pesados sin pausa.'
                      )}
                      className="w-full text-left p-4 rounded-xl border border-slate-200 hover:border-[#1E5FA6] hover:bg-slate-50 transition-all text-xs space-y-1"
                    >
                      <div className="font-bold text-slate-800">Opción B: Continuar sin Aprender (Ignorar Cansancio)</div>
                      <p className="text-slate-500 leading-relaxed">"Considerar que resolver el problema era simplemente su trabajo ordinario. Continuar las labores regulares del lunes sin descanso o análisis de la falla."</p>
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 6: EVALUATION RESULT */}
              {crisisStep === 6 && (
                <div className="p-6 md:p-10 space-y-6 animate-fade-in">
                  <div className="text-center space-y-2">
                    <div className="inline-flex items-center justify-center p-3 bg-blue-100 text-[#1E5FA6] rounded-full">
                      <Award className="w-8 h-8" />
                    </div>
                    <h3 className="text-xl font-black text-slate-800">Evaluación del Desempeño Directivo</h3>
                    <p className="text-xs text-slate-500 max-w-lg mx-auto">
                      Hemos compilado el balance de tus respuestas basadas en las competencias blandas exigidas por la Universidad Ecotec.
                    </p>
                  </div>

                  {/* SCORE PROGRESS BARS */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
                    
                    <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                      <div className="flex justify-between text-xs font-bold text-slate-700">
                        <span>Asertividad</span>
                        <span>{crisisScores.asertividad}%</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div className="bg-[#1E5FA6] h-2 rounded-full transition-all duration-1000" style={{ width: `${crisisScores.asertividad}%` }}></div>
                      </div>
                      <p className="text-[10px] text-slate-500 leading-normal">Capacidad para dialogar de forma franca sin herir susceptibilidades del equipo.</p>
                    </div>

                    <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                      <div className="flex justify-between text-xs font-bold text-slate-700">
                        <span>Liderazgo Activo</span>
                        <span>{crisisScores.liderazgo}%</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div className="bg-emerald-600 h-2 rounded-full transition-all duration-1000" style={{ width: `${crisisScores.liderazgo}%` }}></div>
                      </div>
                      <p className="text-[10px] text-slate-500 leading-normal">Habilidad para mantener al equipo inspirado y con el norte claro en crisis.</p>
                    </div>

                    <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                      <div className="flex justify-between text-xs font-bold text-slate-700">
                        <span>Negociación Asertiva</span>
                        <span>{crisisScores.negociacion}%</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div className="bg-amber-500 h-2 rounded-full transition-all duration-1000" style={{ width: `${crisisScores.negociacion}%` }}></div>
                      </div>
                      <p className="text-[10px] text-slate-500 leading-normal">Facilidad para concretar acuerdos fructíferos en momentos hostiles o de conflicto.</p>
                    </div>

                  </div>

                  {/* CUSTOM DICTAMEN */}
                  <div className="p-6 bg-[#EBF3FC] border-l-8 border-[#1E5FA6] rounded-r-2xl space-y-2">
                    <span className="text-[10px] text-[#1E5FA6] font-bold uppercase tracking-wider block">DICTAMEN DEL INSTRUCTOR</span>
                    <h4 className="font-bold text-slate-800 text-sm">
                      {crisisScores.liderazgo >= 70 && crisisScores.asertividad >= 70 
                        ? 'Estilo de Liderazgo: Líder Transformacional Ecotec (Altamente Asertivo)' 
                        : 'Estilo de Liderazgo: Líder Autocrático o Directivo Tradicional (Requiere Entrenamiento)'}
                    </h4>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {crisisScores.liderazgo >= 70 && crisisScores.asertividad >= 70
                        ? 'Tus elecciones demuestran que valoras la integridad y el cansancio de tu equipo de trabajo humano, a la vez que ofreces soluciones inteligentes al cliente corporativo mediante entregas incrementales y asunción transparente de fallas. ¡Excelente desempeño!'
                        : 'Tiendes a priorizar el control y la jerarquía en escenarios críticos. Esto suele generar un desgaste masivo en el clima organizacional de las startups modernas y aumenta las probabilidades de deserción de talento clave durante situaciones estresantes.'}
                    </p>
                  </div>

                  <div className="pt-4 flex justify-between gap-4 items-center flex-wrap">
                    <button 
                      onClick={resetCrisisSimulation}
                      className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-4 py-2 rounded-xl transition-all"
                    >
                      Reiniciar Simulación
                    </button>

                    <button 
                      onClick={() => setActiveTab('ia_entrenador')}
                      className="bg-[#1E5FA6] hover:bg-[#2D6DB5] text-white text-xs font-bold px-6 py-2 rounded-xl shadow transition-all flex items-center gap-1.5"
                    >
                      <span>Probar el Entrenador de IA</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

            </div>

          </div>
        )}

        {/* ==================== TAB 5: ENTRENADOR IA EN VIVO ==================== */}
        {activeTab === 'ia_entrenador' && (
          <div className="space-y-8 animate-fade-in" id="panel-ia-entrenador">
            
            <div className="text-center max-w-3xl mx-auto space-y-2">
              <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                TECNOLOGÍA EDUCATIVA GEMINI
              </span>
              <h2 className="text-2xl md:text-3xl font-black text-[#1A1A1A]">Entrenador de Habilidades Blandas por IA</h2>
              <p className="text-xs sm:text-sm text-[#444444] leading-relaxed">
                Pon a prueba de forma segura tus habilidades blandas conversacionales chateando en tiempo real con un agente inteligente adaptativo. Gemini asumirá el papel del cliente en crisis, un desarrollador obstinado o un inversionista exigente.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
              
              {/* LEFT SIDE: SELECTION & TOOLKIT DIRECTORY */}
              <div className="lg:col-span-4 space-y-6 flex flex-col">
                
                {/* SELECTOR CARD */}
                <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                  <h3 className="text-sm font-bold text-slate-800 border-b pb-2 flex items-center gap-1.5">
                    <Brain className="w-4.5 h-4.5 text-[#1E5FA6]" />
                    Configuración del Escenario de Chat
                  </h3>

                  <div className="space-y-3">
                    
                    {/* SKILL CHOSEN */}
                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Habilidad a Entrenar</label>
                      <select 
                        value={chatSkill}
                        onChange={(e) => {
                          const val = e.target.value as any;
                          setChatSkill(val);
                          if (val === 'liderazgo') setChatRole('Inversionista Ángel Exigente');
                          else if (val === 'comunicacion') setChatRole('Desarrollador Técnico Obstinado');
                          else setChatRole('Socio Comercial en Pánico');
                        }}
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-[#1E5FA6] outline-none"
                      >
                        <option value="liderazgo">Liderazgo (Inversionista Exigente)</option>
                        <option value="comunicacion">Comunicación Efectiva (Desarrollador Obstinado)</option>
                        <option value="resiliencia">Resiliencia (Socio en Pánico por Competencia)</option>
                      </select>
                    </div>

                    {/* ROLE CUSTOMIZER */}
                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Identidad de la IA</label>
                      <input 
                        type="text" 
                        value={chatRole}
                        onChange={(e) => setChatRole(e.target.value)}
                        placeholder="Ejemplo: Inversionista Ángel de Silicon Valley"
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-[#1E5FA6] outline-none"
                      />
                    </div>

                    <button 
                      onClick={resetChat}
                      className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Reiniciar Conversación</span>
                    </button>

                  </div>
                </div>

                {/* AI TECH DIRECTORY FROM SCREENSHOTS */}
                <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4 flex-1">
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-widest border-b pb-2">
                    Herramientas del Ecosistema IA
                  </h3>
                  
                  <div className="space-y-3.5 text-xs max-h-[250px] overflow-y-auto pr-1">
                    
                    <div className="p-3 bg-[#EBF3FC]/50 rounded-xl border border-blue-100 space-y-1">
                      <span className="font-bold text-[#1E5FA6]">SkillGym y SimSkills</span>
                      <p className="text-[11px] text-slate-500 leading-relaxed">Utilizan avatares interactivos de IA para recrear pláticas gerenciales realistas frente a socios clave.</p>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                      <span className="font-bold text-slate-800">Jenova AI</span>
                      <p className="text-[11px] text-slate-500 leading-relaxed">Adapta dinámicamente complejos escenarios de juego de rol de negocios en base a tus decisiones.</p>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                      <span className="font-bold text-slate-800">CompanyGame AI</span>
                      <p className="text-[11px] text-slate-500 leading-relaxed">Potente simulador de toma de decisiones financieras, de marketing y gestión de personal.</p>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                      <span className="font-bold text-slate-800">Genially</span>
                      <p className="text-[11px] text-slate-500 leading-relaxed">Permite gamificar dinámicas educativas para consolidar asertividad y pensamiento crítico.</p>
                    </div>

                  </div>
                </div>

              </div>

              {/* RIGHT SIDE: LIVE CHAT TERMINAL */}
              <div className="lg:col-span-8 flex flex-col bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden min-h-[480px]">
                
                {/* CHAT STATUS BAR */}
                <div className="bg-[#1E5FA6] p-4 text-white flex justify-between items-center text-xs shrink-0 select-none">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span className="font-bold uppercase tracking-wider font-mono">Simulación de {chatSkill.toUpperCase()} con {chatRole}</span>
                  </div>
                  <span className="bg-[#2D6DB5] text-white text-[10px] px-2.5 py-0.5 rounded-full font-bold">GEMINI FLASH ACTIVE</span>
                </div>

                {/* CHAT MESSAGES BODY */}
                <div className="flex-1 p-6 overflow-y-auto space-y-4 max-h-[350px]" id="chat-messages-container">
                  {chatMessages.map((msg, mIdx) => (
                    <div 
                      key={mIdx} 
                      className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in`}
                    >
                      <div className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed ${
                        msg.role === 'user' 
                          ? 'bg-[#1E5FA6] text-white rounded-tr-none shadow-sm shadow-blue-100' 
                          : 'bg-slate-100 text-slate-700 rounded-tl-none border border-slate-200'
                      }`}>
                        <div className="font-bold text-[9px] uppercase tracking-wider opacity-60 mb-1">
                          {msg.role === 'user' ? 'Tú (Estudiante)' : chatRole}
                        </div>
                        <p className="whitespace-pre-line font-medium">{msg.content}</p>
                      </div>
                    </div>
                  ))}

                  {isChatLoading && (
                    <div className="flex justify-start animate-pulse">
                      <div className="bg-slate-100 text-slate-500 rounded-2xl p-4 text-xs rounded-tl-none border border-slate-200 flex items-center gap-2">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#1E5FA6]" />
                        <span>{chatRole} está redactando su respuesta...</span>
                      </div>
                    </div>
                  )}

                  {chatError && (
                    <div className="p-3.5 bg-red-50 text-red-700 border border-red-100 rounded-xl text-xs flex items-center gap-2">
                      <X className="w-4 h-4 shrink-0" />
                      <span>{chatError}</span>
                    </div>
                  )}
                </div>

                {/* BOTTOM CHAT INPUT FIELD */}
                <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-200 bg-slate-50 flex gap-3 shrink-0">
                  <input 
                    type="text" 
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Escribe tu respuesta con la mayor asertividad, empatía y técnica posible..."
                    className="flex-1 text-xs p-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1E5FA6] placeholder-slate-400 shadow-inner"
                    disabled={isChatLoading}
                  />
                  <button 
                    type="submit"
                    disabled={isChatLoading || !chatInput.trim()}
                    className="bg-[#1E5FA6] hover:bg-[#2D6DB5] text-white px-4 py-3 rounded-xl transition-all shadow-md disabled:bg-slate-300 flex items-center justify-center"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>

              </div>

            </div>

          </div>
        )}

      </main>

      {/* FOOTER INSTITUCIONAL COMPLIANT STYLING */}
      <footer className="bg-white border-t border-slate-200 select-none py-6 shrink-0" id="main-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="h-1 bg-[#2D6DB5] w-full mb-4 rounded-full"></div>
          <div className="flex flex-col sm:flex-row justify-between items-center text-xs text-slate-500 font-bold tracking-wider gap-4">
            <div className="flex items-center gap-4">
              <span>f @universidadecotec</span>
              <span>•</span>
              <span>📷 uecotec</span>
            </div>
            <div className="text-center sm:text-right font-medium">
              Universidad Ecotec - Dirección de Diseño Instruccional y Grado Académico
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
}
